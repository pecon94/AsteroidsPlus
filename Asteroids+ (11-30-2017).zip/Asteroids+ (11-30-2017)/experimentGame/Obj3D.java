package experimentGame;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.jogamp.opengl.GL2;

class Obj3D
{
	private ArrayList<Point3D> objTrigons;
	private ArrayList<Point2D> textCoords;
	private ArrayList<Face> face;
	private ArrayList<Face> textFace;
	private String buffer;
	
	//Object file reader, reads in OBJ files, similar to what we had seen in class but modified to work with objects made in blender.
	public Obj3D(String file) 
	{
		try {
		objTrigons = new ArrayList<>();
		face = new ArrayList<>();
		textFace = new ArrayList<>();
		//textFace.add(null);
		textCoords = new ArrayList<>();
		File shipOBJ = new File(file);
		Scanner scanner = new Scanner(shipOBJ);
		String firstChar;
		
		
		buffer = scanner.nextLine();
		buffer = scanner.nextLine();
		int i=0;
		while(true)
		{
			if(scanner.hasNext())
			{
				firstChar = scanner.next(); 
				//System.out.println(firstChar);
				if(firstChar.equals("v"))         
				{
					 
					
					 
						 
						objTrigons.add(new Point3D(scanner.nextFloat(),scanner.nextFloat(),scanner.nextFloat()));
						//System.out.println("Value of i: " + i);
						//System.out.println("x: " + objTrigons.get(i).x + "y: " +  objTrigons.get(i).y + "z: " +  objTrigons.get(i).z);
						i++;
					
				}
				else if(firstChar.equals("vt"))
				{
					textCoords.add(new Point2D(scanner.nextFloat(), scanner.nextFloat()));
				}
				else if(firstChar.equals("s"))
				{
					buffer = scanner.nextLine();
				}
				else if(firstChar.equals("f"))
				{
					while (scanner.hasNextLine())
					{
						//System.out.println("I am groot");
						int[] buffy = new int[3];
						int[] truffy = new int[3];
						int k=0;
						//String helper;
						char[] helper;
						String num ="";
						boolean hasValues=false, faceToggle = true, flag = false, flag2 = false;
						
						
						firstChar = scanner.nextLine();
						helper = firstChar.toCharArray();
						if(helper[0] == 's')
						{
							firstChar = scanner.nextLine();
							helper = firstChar.toCharArray();
						}
						
						for(int j =0; j<firstChar.length(); j++)
						{
							if(helper[j] != '/' && helper[j] != ' ' && helper[j] != 'f') {
								//System.out.println("I shouldnt be here");
								num += helper[j];
								hasValues=true;
								
									
								
							}
							else if(flag && helper[j] == ' ')
								flag2 = true; 
							else if(helper[j] == '/')
								flag = true;
							
							
							if(hasValues && flag)
							{
								//flag = !flag;
								if(faceToggle && !flag2) {
									buffy[k] = Integer.parseInt(num);
									
									
									faceToggle = false;
									hasValues = false;
									num = "";
								}
								else if(!faceToggle && flag2){
									truffy[k] = Integer.parseInt(num);
									//System.out.println("Truffy: " + truffy[k]);
									flag = false;
									flag2 = false;
									faceToggle = true;
									hasValues = false;
									k++;
									num = "";
									if(k>2)
										k=0;
								}
						}
						
					}
					
					
					face.add(new Face(buffy[0], buffy[1], buffy[2]));
					textFace.add(new Face(truffy[0], truffy[1], truffy[2]));
					}
				}
				else
					break;
			}
			else
				break;
		}
		
		}
		catch(FileNotFoundException ex) {System.out.println("Unable to open file");}
		catch(IOException ex) {System.out.println("Error reading file");}
		catch(InputMismatchException ex) {System.out.println("Error! \nRead value had an unexpected data type!");}
		System.out.println("Face Length: " + face.size());
		for(int i =0; i<face.size(); i++)
		{
			System.out.println(face.get(i).getFace()[0] + ", " + face.get(i).getFace()[1] + ", " + face.get(i).getFace()[2]);
			 
			
		}
		//System.out.println(x);
		
            

	}
	public void draw(GL2 gl, float scalar, float R, float G, float B){
		gl.glBegin(GL2.GL_TRIANGLES);                    
	   
	   //Quick coloring for rendered objects (for testing).
		float scale = scalar;
		int j = 0;
		for(int i = 0; i<face.size(); i++)
		{
			gl.glColor3f(R, G, B);
			gl.glVertex3f(
			objTrigons.get(face.get(i).getFace()[0]-1).x*scale,
			objTrigons.get(face.get(i).getFace()[0]-1).y*scale,
			objTrigons.get(face.get(i).getFace()[0]-1).z*scale);
			//System.out.println("Vertex " + j++ );
			gl.glVertex3f(
			objTrigons.get(face.get(i).getFace()[1]-1).x*scale,
			objTrigons.get(face.get(i).getFace()[1]-1).y*scale,
			objTrigons.get(face.get(i).getFace()[1]-1).z*scale);
			//System.out.println("Vertex " + j++ );
			gl.glVertex3f(
			objTrigons.get(face.get(i).getFace()[2]-1).x*scale,
			objTrigons.get(face.get(i).getFace()[2]-1).y*scale,
			objTrigons.get(face.get(i).getFace()[2]-1).z*scale);
			//System.out.println("Vertex " + j++ );
			/*R+= 0.010;
			G+= 0.012;
			B+= 0.017;
			 */
	}
	gl.glEnd();
	}
	public void draw(GL2 gl, float scalar)
	{
		gl.glBegin(GL2.GL_TRIANGLES);                    
	    
	    //Quick coloring for rendered objects (for testing).
		float scale = scalar;
		float R=0.2F, G=0.2F, B=0.2F;
		for(int i = 0; i<face.size(); i++)
		{
			gl.glColor3f(R, G, B);
			gl.glVertex3f(
					objTrigons.get(face.get(i).getFace()[0]-1).x*scale, 
					objTrigons.get(face.get(i).getFace()[0]-1).y*scale, 
					objTrigons.get(face.get(i).getFace()[0]-1).z*scale); 
			gl.glVertex3f(
					objTrigons.get(face.get(i).getFace()[1]-1).x*scale, 
					objTrigons.get(face.get(i).getFace()[1]-1).y*scale, 
					objTrigons.get(face.get(i).getFace()[1]-1).z*scale); 
			gl.glVertex3f(
					objTrigons.get(face.get(i).getFace()[2]-1).x*scale, 
					objTrigons.get(face.get(i).getFace()[2]-1).y*scale, 
					objTrigons.get(face.get(i).getFace()[2]-1).z*scale); 
			R+= 0.010;
			G+= 0.012;
			B+= 0.017;
		}
		gl.glEnd();
	}
	public void draw(GL2 gl, float scalar, int texture) 
	{
		//gl.glColor3f(1,1,1);
		gl.glBindTexture(GL2.GL_TEXTURE_2D, texture);
		gl.glEnable(GL2.GL_TEXTURE_2D);
		gl.glBegin(GL2.GL_TRIANGLES);                    
	    gl.glColor3f(1, 1, 1);
	    float scale = scalar;
	 
		for(int i = 0; i<face.size(); i++)
		{
			
			gl.glTexCoord2d(
					textCoords.get(textFace.get(i).getFace()[0]).x,
					textCoords.get(textFace.get(i).getFace()[0]).y);
			//System.out.println("x: " + textCoords.get(textFace.get(i).getFace()[0]-1).x + "y: "+
					//textCoords.get(textFace.get(i).getFace()[0]-1).y);
			gl.glVertex3f(
					objTrigons.get(face.get(i).getFace()[0]-1).x*scale, 
					objTrigons.get(face.get(i).getFace()[0]-1).y*scale, 
					objTrigons.get(face.get(i).getFace()[0]-1).z*scale); 
			gl.glTexCoord2d(
					textCoords.get(textFace.get(i).getFace()[1]).x,
					textCoords.get(textFace.get(i).getFace()[1]).y);
			//System.out.println("x: " + textCoords.get(textFace.get(i).getFace()[1]-1).x + "y: "+
				//	textCoords.get(textFace.get(i).getFace()[1]).y);
			gl.glVertex3f(
					objTrigons.get(face.get(i).getFace()[1]-1).x*scale, 
					objTrigons.get(face.get(i).getFace()[1]-1).y*scale, 
					objTrigons.get(face.get(i).getFace()[1]-1).z*scale); 
			
			gl.glTexCoord2d(
					textCoords.get(textFace.get(i).getFace()[2]).x,
					textCoords.get(textFace.get(i).getFace()[2]).y);
			//System.out.println("x: " + textCoords.get(textFace.get(i).getFace()[2]).x + "y: "+
			//		textCoords.get(textFace.get(i).getFace()[2]).y);
			gl.glVertex3f(
					objTrigons.get(face.get(i).getFace()[2]-1).x*scale, 
					objTrigons.get(face.get(i).getFace()[2]-1).y*scale, 
					objTrigons.get(face.get(i).getFace()[2]-1).z*scale); 
			
		}
		gl.glEnd();
		gl.glDisable(GL2.GL_TEXTURE_2D);
		
		
	}
	
	
}

class Face
{
	private int[] face;
	public Face(int v1, int v2, int v3)
	{
		face = new int[3];
		setFaces(v1, v2, v3);
		
	}
	public void setFaces (int v1, int v2, int v3)
	{
		face[0] = v1;
		face[1] = v2;
		face[2] = v3;
	}
	public int[] getFace()
	{
		return face;
	}
}

class Point3D{
	float x, y, z;
	Point3D(float x, float y, float z){
		this.x=x;
		this.y=y;
		this.z=z;
	}
}
class Point2D{
	float x, y, z;
	Point2D(float x, float y){
		this.x=x;
		this.y=y;
	}
}