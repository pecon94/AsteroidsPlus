package experimentGame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.KeyStroke;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.GLProfile;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.FPSAnimator;

public class Render{

	private static Dimension xgraphic;
	private static boolean isFullScreen = false;
	private static Point point = new Point(0, 0);
	private static JFrame frame;
	//Screen size
	public static int screenWidth = 1024;
	public static int screenHeight = 768;
	
	
	public static void main(String[] args) {
		//setup open GL version 2
		MainWindow MAIN = new MainWindow(screenWidth, screenHeight);
		frame = new JFrame ("Ateroids+!"); //Frame name.
		frame.getContentPane().add(MAIN.glcanvas);	//Adding canvas to the frame.
		frame.setSize(frame.getContentPane().getPreferredSize());//Setting frame size to canvas size.
		
		/**This part centers the screen on start up*/
		//Unused portion of code used for detecting multiple displays and obtain data from the first one in order to center the game.
		/*GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice[] devices = graphicsEnvironment.getScreenDevices(); 
		DisplayMode dm_old = devices[0].getDisplayMode();
		DisplayMode dm=dm_old;*/	
		/**This is where we actually center the screen*/
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int windowX = Math.max(0, (screenSize.width - frame.getWidth())/2);
		int windowY = Math.max(0,  (screenSize.height - frame.getHeight())/2);
		frame.setLocation(windowX,  windowY);
		frame.setVisible(true);
		
		//Adding button control
		JPanel p = new JPanel();
		p.setPreferredSize(new Dimension(0,0));
		frame.add(p,BorderLayout.SOUTH);
		
		keyBindings(p, frame, MAIN);
		
		//Shutdown
		frame.addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){
			if(MAIN.animator.isStarted())
				MAIN.animator.stop();
			System.exit(0);
		}});
		
	}
	public static int getWindowWidth(){
		return frame.getWidth();
	}
	public static int getWindowHeight(){
		return frame.getHeight();
	}
	private static void keyBindings(JPanel p, final JFrame frame, MainWindow m) {
		ActionMap actionMap = p.getActionMap();
		InputMap inputMap = p.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW); //Allows out JPanel of size (0,0) to be focused.
		//Assigning a command to key F1.
		inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_F1,0),  "F1");
		actionMap.put("F1",  new AbstractAction(){

			@Override
			public void actionPerformed(ActionEvent e) {
				fullScreen(frame);
			}});
	}
	//Calling full screen mode.
	private static void fullScreen(final JFrame frame){
		if(!isFullScreen){
			frame.dispose();
			frame.setUndecorated(true);
			frame.setVisible(true);
			frame.setResizable(false);
			xgraphic = frame.getSize();
			point = frame.getLocation();
			frame.setLocation(0, 0);
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			frame.setSize((int)screenSize.getWidth(), (int)screenSize.getHeight());
			isFullScreen = true;
		}else{
			frame.dispose();
			frame.setUndecorated(false);
			frame.setResizable(true);
			frame.setLocation(point);
			frame.setSize(xgraphic);
			frame.setVisible(true);
			
			isFullScreen = false;
		}
	}
}