package experimentGame;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.jogamp.opengl.GL2;

class Obj3D
{
	private ArrayList<Point3D> shipTrigons;
	private ArrayList<Face> face;
	private String buffer;
	
	//Object file reader, reads in OBJ files, similar to what we had seen in class but modified to work with objects made in blender.
	public Obj3D(String file) 
	{
		try {
		shipTrigons = new ArrayList<>();
		face = new ArrayList<>();
		File shipOBJ = new File(file);
		Scanner scanner = new Scanner(shipOBJ);
		char firstChar;
		
		
		buffer = scanner.nextLine();
		buffer = scanner.nextLine();
		int i=0;
		while(true)
		{
			if(scanner.hasNext())
			{
				firstChar = scanner.next(".").charAt(0); 
				if(firstChar=='v')         
				{
					shipTrigons.add(new Point3D(scanner.nextFloat(),scanner.nextFloat(),scanner.nextFloat()));
					System.out.println("Value of i: " + i);
					System.out.println("x: " + shipTrigons.get(i).x + "y: " +  shipTrigons.get(i).y + "z: " +  shipTrigons.get(i).z);
					i++;
				}
				else if(firstChar=='s')
				{
					buffer = scanner.nextLine();
				}
				else if(firstChar=='f')
				{
					
					face.add(new Face(scanner.nextInt(), scanner.nextInt(), scanner.nextInt()));
				}
				else
					break;
			}
			else
				break;
		}
		
		}
		catch(FileNotFoundException ex) {System.out.println("Unable to open file");}
		catch(IOException ex) {System.out.println("Error reading file");}
		catch(InputMismatchException ex) {System.out.println("Error! \nRead value had an unexpected data type!");}
		
            

	}
	public void draw(GL2 gl, float scalar)
	{
		gl.glBegin(GL2.GL_TRIANGLES);                    
	    
	    //Quick coloring for rendered objects (for testing).
		float scale = scalar;
		float R=0.2F, G=0.2F, B=0.2F;
		for(int i = 0; i<face.size(); i++)
		{
			gl.glColor3f(R, G, B);
			gl.glVertex3f(
					shipTrigons.get(face.get(i).getFace()[0]-1).x*scale, 
					shipTrigons.get(face.get(i).getFace()[0]-1).y*scale, 
					shipTrigons.get(face.get(i).getFace()[0]-1).z*scale); 
			gl.glVertex3f(
					shipTrigons.get(face.get(i).getFace()[1]-1).x*scale, 
					shipTrigons.get(face.get(i).getFace()[1]-1).y*scale, 
					shipTrigons.get(face.get(i).getFace()[1]-1).z*scale); 
			gl.glVertex3f(
					shipTrigons.get(face.get(i).getFace()[2]-1).x*scale, 
					shipTrigons.get(face.get(i).getFace()[2]-1).y*scale, 
					shipTrigons.get(face.get(i).getFace()[2]-1).z*scale); 
			R+= 0.010;
			G+= 0.012;
			B+= 0.017;
		}
		gl.glEnd();
	}
	
	
}

class Face
{
	private int[] face;
	public Face(int v1, int v2, int v3)
	{
		face = new int[3];
		setFaces(v1, v2, v3);
		
	}
	public void setFaces (int v1, int v2, int v3)
	{
		face[0] = v1;
		face[1] = v2;
		face[2] = v3;
	}
	public int[] getFace()
	{
		return face;
	}
}

class Point3D{
	float x, y, z;
	Point3D(float x, float y, float z){
		this.x=x;
		this.y=y;
		this.z=z;
	}
}