package experimentGame;

class PlayerShip{
	float posX, posY, preX, preY;
	float rotate= 2f, friction= 0.97f, spd=0.15f, rotation=0, sx,sy;
	float tilt=0, tiltLimit=30; //Gives the ship a tilt when turning.
	int shipH=60, shipW=30;//ship dimensions for 2d, but unused after changing to 3d Models.
	boolean left, right, up, down, thrust;
	int screenX, screenY;
	
	//Initializing our ship, we need its position relative to the canvas, and the canvas dimensions (x and y).
	PlayerShip(int x, int y, int sx, int sy){
		posX= x;
		posY= y;
		screenX= sx;
		screenY= sy;
	} 
	//This Function is called by our main window every frame to check for movement and calculate it.
	public void move()
	{
		preX= posX;	//storing previous position, unused but could come in handy.
		preY= posY;
		if(right){
			rotation= (rotation-rotate)%360; //makes sure our rotation values never go beyond 360.
			if(tilt<tiltLimit)
			tilt+=2;
		}
		else if(left){
			rotation=(rotation+rotate)%360;
			if(tilt>-tiltLimit)
				tilt-=2;
		}
		if(up){
				sy+=Math.sin(Math.toRadians(rotation))*spd;
				sx+=Math.cos(Math.toRadians(rotation))*spd;
			
		}
		//Ship repositioning is defined by the addition of the accumulated values in sx and sy, then it decays with friction.
		posX+=sx;
		posY+=sy;
		sx*=friction;
		sy*=friction;
		tilt*=friction;	//applied the same idea to the ship tilt so it stabilizes smoothly.
	
		//Resetting position, basically keeping the ship in frame.
		if (posX>(screenX/2))
			posX=(-screenX/2);
		if (posX<(-screenX/2))
			posX=(screenX/2);
		if (posY>(screenY/2))
			posY=(-screenY/2);
		if (posY<(-screenY/2))
			posY=screenY/2;
		//System.out.println("Ship at point: "+(int)posX+" , "+(int)posY);
	}
	public float getPosX()
	{
		return posX;
	}
	public float getPosY()
	{
		return posY;
	}
}

