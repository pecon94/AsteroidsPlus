package experimentGame;

import java.awt.DisplayMode;
import java.awt.GraphicsEnvironment;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.sound.sampled.Clip;
import javax.swing.JPanel;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.GLProfile;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.FPSAnimator;

class MainWindow extends JPanel implements GLEventListener, KeyListener{
	private PlayerShip player;
	private PlaySound BGM, FX;
	private String bgm1="sound\\BGM\\bgm.wav", fx1="sound\\FX\\thrust.wav";
	private Clip BGMClip, thrust;
	private int metOnScreen=5;
	private ArrayList<Meteors> meteors= new ArrayList<Meteors>();
	private int gameFieldX=640, gameFieldY=480;
	private Obj3D ship, met3D;
	private String shipObj="src\\objects\\ship_new.obj", meteorObj="src\\objects\\meteor.obj";
	FPSAnimator animator;
	public GLCanvas glcanvas;
	
	private int blowUpCount=0;
	
	private GLU glu = new GLU();
	
	public MainWindow(int screenWidth, int screenHeight){
		
		final GLProfile profile = GLProfile.get(GLProfile.GL2);
		GLCapabilities capabilities = new GLCapabilities(profile);
		//The canvas
		glcanvas = new GLCanvas(capabilities);
		glcanvas.addGLEventListener (this); //allows us to use the keyboard with the window.
		glcanvas.setSize(screenWidth,screenHeight);
		glcanvas.addKeyListener(this);
		
		//Creating a player
		player = new PlayerShip(0,0,gameFieldX,gameFieldY);
		ship=new Obj3D(shipObj);
		
		//creating meteors on screen and storing them into an array
		for(int i=0; i<metOnScreen;i++){
			meteors.add(new Meteors(gameFieldX,gameFieldY));
		}
		met3D=new Obj3D(meteorObj);//importing the 3D model for the Meteors (location defined in string meteorObj).
		
		//Creating sound
		BGM=new PlaySound();
		BGMClip=BGM.playBGM(bgm1);
		
		//Creating the animator for this window
		animator = new FPSAnimator(glcanvas, 60, true);
		animator.start();
	}

	@Override
	public void display(GLAutoDrawable drawable) {
		//drawing stuff here~
		final GL2 gl= drawable.getGL().getGL2();
		gl.glClear(GL2.GL_COLOR_BUFFER_BIT|GL2.GL_DEPTH_BUFFER_BIT); //Clear the screen and the depth buffer
		
		//Probably our most important section, here we draw everything on the canvas.
		gl.glLoadIdentity();				//resets values of gl Matrix
		gl.glTranslatef(player.getPosX(),player.getPosY(),-530); //places objects at -530 in Z (calculated to obtain desired logical units).
		gl.glRotatef(player.rotation, 0, 0, 1);					 //makes the ship face in the desired direction.
		gl.glRotatef(player.tilt, 1f, 0, 0);					 //adds tilting effect, calculated within playerShip.
		ship.draw(gl, 5);										 //calls object reader to draw out model.
		
		//This draws our meteors and fragments if a meteor is destroyed.
		for(int i=0; i<meteors.size();i++){	
			gl.glLoadIdentity();
			gl.glTranslatef(meteors.get(i).getPosX(),meteors.get(i).getPosY(),-530);
			gl.glRotatef(meteors.get(i).getRotation(), 1, 1, 1);
			
			//If it's alive, we draw it!
			if(meteors.get(i).isAlive){
				met3D.draw(gl, meteors.get(i).getRadius());
				meteors.get(i).move();
			}	
			//if not, then we do its fragments.
			else{
				for(int j=0;j<meteors.get(i).frags.size();j++){
					gl.glLoadIdentity();
					gl.glTranslatef(meteors.get(i).frags.get(j).X,meteors.get(i).frags.get(j).Y,-530);
					gl.glRotatef(meteors.get(i).frags.get(j).rt, 1, 1, 1);
					met3D.draw(gl, meteors.get(i).frags.get(j).rad);
					meteors.get(i).frags.get(j).move();
				}
			}
		}
		gl.glFlush();
		player.move();
		checkSound(); //Calls to check on SFX.
	}
	private void checkSound(){
		//Lets the ship make some noise while accelerating.
		if (player.up&&!player.thrust){
			thrust=BGM.playBGM(fx1);
			player.thrust=true;
		}else if(!player.up && player.thrust){
			player.thrust=false;
			thrust.stop();
		}
	}
		
	@Override
	public void dispose(GLAutoDrawable drawable) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init(GLAutoDrawable drawable) {
		//initializing OpenGL elements for this window~
		final GL2 gl=drawable.getGL().getGL2();
		gl.glShadeModel(GL2.GL_SMOOTH);
		gl.glClearColor(0f, 0f, 0f, 1f);
		gl.glClearDepth(1.0f);
		gl.glEnable(GL2.GL_DEPTH_TEST);
	    gl.glDepthFunc(GL2.GL_LEQUAL);
		gl.glHint(GL2.GL_PERSPECTIVE_CORRECTION_HINT, GL2.GL_NICEST);		
	}

	@Override
	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
		final GL2 gl = drawable.getGL().getGL2();
		
		if(height<=0)
			height=1;
		final float h=(float)width/(float)height;	//calculating h= window width/height.
		gl.glViewport(0,0,Render.getWindowWidth(),Render.getWindowHeight());	//position set for view port
		gl.glMatrixMode(GL2.GL_PROJECTION);
		gl.glLoadIdentity();
		
		//Using a 2d Plane with 2d Graphics
		//gl.glOrtho(0, glcanvas.getWidth(), glcanvas.getHeight(), 0, -1, 1);
		//gl.glMatrixMode(GL2.GL_MODELVIEW);
		//gl.glMatrixMode(GL2.GL_MODELVIEW);
		//gl.glLoadIdentity();
		//gl.glFrustum(0, glcanvas.getWidth(), glcanvas.getHeight(), 0, 0.9999f, 10);
		//Implementing 3D with perspective view.
		/**Using a 3D perspective after calculating Z distance for drawing for a fixed amount of logical units on X and Y*/
		glu.gluPerspective(45F, h,1f, 1000f); //View angle is 45deg, renders from unit 1000 to 2000, aspect ratio "h" calculated above.
		gl.glMatrixMode(GL2.GL_MODELVIEW);
		gl.glLoadIdentity();
	}
	//Key listener instructions! We're letting the ship know what keys are being pressed so it can do it's thing!
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			player.right=true;
		if(e.getKeyCode() == KeyEvent.VK_LEFT)
			player.left=true;
		if(e.getKeyCode() == KeyEvent.VK_UP)
			player.up=true;
		if(e.getKeyCode() == KeyEvent.VK_DOWN)
			player.down=true;
		
		//FOR TESTING!!! This key "A" will blow up the meteors to see the fragments in action.
		if(e.getKeyCode() == KeyEvent.VK_A){
			if(blowUpCount<meteors.size()){
				meteors.get(blowUpCount).blowsUp();
				blowUpCount++;
				}
		}	
	}
	//Lets our ship know we are no longer pressing the keys.
	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			player.right=false;
		if(e.getKeyCode() == KeyEvent.VK_LEFT)
			player.left=false;
		if(e.getKeyCode() == KeyEvent.VK_UP)
			player.up=false;
		if(e.getKeyCode() == KeyEvent.VK_DOWN)
			player.down=false;
	}

	@Override
	public void keyTyped(KeyEvent e) {}
}