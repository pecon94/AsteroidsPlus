package experimentGame;

import java.util.ArrayList;

public class Meteors {
	public boolean isAlive= true;
	private float radius = 15, posX, posY, speedX, speedY, rotation, rotInc;
	public int screenX, screenY;
	public ArrayList<Fragments> frags = new ArrayList<Fragments>();
	
	Meteors(){
		//Explicit empty super constructor
	}
	//Creates "Space Rocks~"
	Meteors(int x, int y){
		screenX=x;
		screenY=y;
		speedX=(float)(Math.random()-0.5f)*2; //generates random values so each meteor behaves differently.
		speedY=(float)(Math.random()-0.5f)*2;
		rotInc=(float)(Math.random()-0.5F)*10;
		posX=0;
		posY=0;
	}
	public void move(){
		posX+=speedX;
		posY+=speedY;
		rotation=(rotation+rotInc)%360;
		
	//Keeping meteors in frame
		if (posX>(screenX/2))
			posX=(-screenX/2);
		if (posX<(-screenX/2))
			posX=(screenX/2);
		if (posY>(screenY/2))
			posY=(-screenY/2);
		if (posY<(-screenY/2))
			posY=screenY/2;
	}
	public void blowsUp(){
		//Play FX here (haven't assigned a sound effect yet, but it will be played when this function is called).
		//Create fragment Array (4 fragments for any meteor broken.
		isAlive=false;
		for(int i=0;i<4;i++)
			frags.add(new Fragments(posX, posY, screenX, screenY));
	}
	public float getPosX(){
		return posX;
	}
	public float getPosY(){
		return posY;
	}
	public float getRadius() {
		return radius;
	}
	public void setRadius(float radius) {
		this.radius = radius;
	}
	public float getRotation() {
		return rotation;
	}
	public void setRotation(float rotation) {
		this.rotation = rotation;
	}
}

class Fragments extends Meteors{
	public float rad=8, X, Y, spdX, spdY, rt, rtI, sX, sY;
	boolean isAlive=true;
	//Follows a similar behavior as its parent
	Fragments(float posX, float posY, float screenX, float screenY){
		X=posX;
		Y=posY;
		sX=screenX;
		sY=screenY;
		spdX=(float)(Math.random()-0.5f)*2;
		spdY=(float)(Math.random()-0.5f)*2;
		rtI=(float)(Math.random()-0.5F)*10;
	}
	public void move(){
		X+=spdX;
		Y+=spdY;
		rt=(rt+rtI)%360;
		
	//Keeping fragments in frame 
		if (X>(sX/2))
			X=(-sX/2);
		if (X<(-sX/2))
			X=(sX/2);
		if (Y>(sY/2))
			Y=(-sY/2);
		if (Y<(-sY/2))
			Y=sY/2;
	}
}
