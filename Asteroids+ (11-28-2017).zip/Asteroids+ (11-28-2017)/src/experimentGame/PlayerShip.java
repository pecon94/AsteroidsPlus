package experimentGame;

import java.util.ArrayList;

class PlayerShip{
	float posX, posY, preX, preY;
	float rotate= 2f, friction= 0.97f, spd=0.25f, rotation=0, sx,sy;
	int scale=5;
	float tilt=0, tiltLimit=30; //Gives the ship a tilt when turning.
	int shipH=60, shipW=30;//ship dimensions for 2d, but unused after changing to 3d Models.
	boolean isAlive=true, left, right, up, down, thrust, shoot=true, shooting;
	int screenX, screenY;
	int playerScore=0;
	
	private int bulletCount=0, bulletMax=5;
	ArrayList<Bullets> bullets= new ArrayList<Bullets>();
	//Initializing our ship, we need its position relative to the canvas, and the canvas dimensions (x and y).
	PlayerShip(int x, int y, int sx, int sy){
		posX= x;
		posY= y;
		screenX= sx;
		screenY= sy;
	} 
	public void blowsUp(){
		isAlive=false;
		System.out.println("Player is Dead");
	}
	//This Function is called by our main window every frame to check for movement and calculate it.
	public void move()
	{
		preX= posX;	//storing previous position, unused but could come in handy.
		preY= posY;
		if(right){
			rotation= (rotation-rotate)%360; //makes sure our rotation values never go beyond 360.
			if(tilt<tiltLimit)
			tilt+=2;
		}
		else if(left){
			rotation=(rotation+rotate)%360;
			if(tilt>-tiltLimit)
				tilt-=2;
		}
		if(up){
				sy+=Math.sin(Math.toRadians(rotation))*spd;
				sx+=Math.cos(Math.toRadians(rotation))*spd;
			
		}
		//Ship repositioning is defined by the addition of the accumulated values in sx and sy, then it decays with friction.
		posX+=sx;
		posY+=sy;
		sx*=friction;
		sy*=friction;
		tilt*=friction;	//applied the same idea to the ship tilt so it stabilizes smoothly.
	
		//Resetting position, basically keeping the ship in frame.
		if (posX>(screenX/2))
			posX=(-screenX/2);
		if (posX<(-screenX/2))
			posX=(screenX/2);
		if (posY>(screenY/2))
			posY=(-screenY/2);
		if (posY<(-screenY/2))
			posY=screenY/2;
		//System.out.println("Ship at point: "+(int)posX+" , "+(int)posY);
		if(shooting&&shoot){
			if(bulletCount<bulletMax){
				bullets.add(new Bullets(rotation, posX, posY));
				bulletCount++;
				shoot=false;
			}
		}
		for(int j=0; j<bullets.size();j++){
			if(bullets.get(j).isAlive)
				bullets.get(j).move();
			else{
				bullets.remove(j);
				bulletCount--;
			}
		}
	}
	public float getPosX()
	{
		return posX;
	}
	public float getPosY()
	{
		return posY;
	}
}
class Bullets{
	float posX, posY, distX, distY, rotation, speed=10f, maxDistance=1200;
	int screenX, screenY;
	boolean isAlive=true;
	Bullets(float pRotation, float posX, float posY){
		this.posX=(float) (posX+Math.cos(Math.toRadians(pRotation))*5);
		this.posY=(float) (posY+Math.sin(Math.toRadians(pRotation))*5);
		this.rotation=pRotation;
	}
	public void move(){
		if(Math.sqrt((distX*distX)+(distY*distY))<maxDistance){
		  float temp;
		  temp=(float) Math.cos(Math.toRadians(rotation))*speed;
		  posX+=temp;
		  distX+=temp;
		  temp=(float) Math.sin(Math.toRadians(rotation))*speed;
		  posY+=temp;
		  distY+=temp;
	  }
		else
			isAlive=false;
	}
}

