package experimentGame;

import java.io.File;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

class PlaySound
{
	public Clip playBGM(String f)
	{
		//plays the sound of the string path that is provided to the file object
		try{
			File file = new File(f);
			Clip clip = AudioSystem.getClip();
			AudioInputStream ais = AudioSystem.getAudioInputStream( file );
			clip.open(ais);
			clip.loop(Clip.LOOP_CONTINUOUSLY);
			return clip;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
		
	}
	public void playFX(String fx)
	{
		//Plays a clip and ends when clip is done, shouldn't loop.
		try{
			File file = new File(fx);
			Clip clip = AudioSystem.getClip();
			AudioInputStream ais = AudioSystem.
					getAudioInputStream( file );
			clip.open(ais);
			//clip.loop(Clip.LOOP_CONTINUOUSLY);
			clip.start();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}